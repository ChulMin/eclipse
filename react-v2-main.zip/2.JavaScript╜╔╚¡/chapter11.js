console.log(1);

setTimeout(() => {
  console.log(2);
}, 3000);

console.log(3);
