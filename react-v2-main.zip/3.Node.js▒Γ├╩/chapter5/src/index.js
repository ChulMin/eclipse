import mul, { add, sub } from "./math.js";

import randomcolor from "randomcolor";

const color = randomcolor();
console.log(color);

// console.log(add(1, 2));
// console.log(sub(1, 2));
// console.log(mul(2, 3));
