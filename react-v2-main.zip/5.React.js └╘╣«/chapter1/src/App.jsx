import "./App.css";

function App() {
  return (
    <>
      <h1>안녕 리액트!</h1>
    </>
  );
}

export default App;
