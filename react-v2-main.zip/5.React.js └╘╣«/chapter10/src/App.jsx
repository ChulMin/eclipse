import "./App.css";
import Register from "./components/Register";

function App() {
  return (
    <>
      <Register />
      <Register />
    </>
  );
}

export default App;
