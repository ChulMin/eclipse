const Footer = () => {
  return (
    <footer>
      <h1>footer</h1>
    </footer>
  );
};

export default Footer;
