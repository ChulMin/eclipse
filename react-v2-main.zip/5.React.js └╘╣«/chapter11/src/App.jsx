import "./App.css";
import Register from "./components/Register";
import HookExam from "./components/HookExam";

function App() {
  return (
    <>
      <HookExam />
    </>
  );
}

export default App;
