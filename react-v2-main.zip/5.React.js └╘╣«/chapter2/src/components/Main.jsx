const Main = () => {
  return (
    <main>
      <h1>main</h1>
    </main>
  );
};

export default Main;
