/**
 * 
 */
/**
 * 
 */
module DBMS_JAVA {
	requires java.sql;
}