-- primary key: 주키, 기본키, 역할: 검색할 때 기본키(기준이 되는 키값)가 되어 사용합니다.
-- 다른 의미는 데이터의 중복 배제 효과
-- not null 효과 + Unique 효과
-- name char(5): 만약에 hy를 입력하면, 2바이트 사용되고, 나머지 3바이트는 낭비됩니다.
-- name varchar(5): mySQL, String(java), hy 데이터가 들어오면 2바이트 할당, 메모리 낭비가 방지
-- name varchar2(5): Oracle

create table member(
	m_id varchar2(15) primary key,
	m_name varchar2(30) not null, -- m_name 이라는 데이터 데이터를 반드시 입력해주세요. 한글자당 2byte
	m_height number(5,3) default 0.00,-- 99.999 
	m_weight number(5,2) default 0.00,-- 999.99
	m_age number(3) default 0 --999
);

select * from member;

insert into member(m_id,m_name,m_height,m_weight,m_age)
			values('20240001','홍길동',176.45,80.19,35);
insert into member(m_id,m_name,m_height,m_weight,m_age)
			values('20240002','현대빈',196.45,90.58,25);
insert into member(m_id,m_name,m_height,m_weight,m_age)
			values('20240003','김철민',276.45,180.26,27);
insert into member(m_id,m_name,m_height,m_weight,m_age)
			values('20240004','김철민2',276.45,180.45,27);
insert into member(m_name,m_id,m_height,m_weight,m_age)
			values('20240006','김철민3',276.45,180.45,27);
delete from member;



create table member2(
	m_id char(10) primary key,
	m_name varchar2(30) not null,
	m_height number(3) default 0.00,
	m_weight number(5,2) default 0.00,
	m_age number(3) default 0
);	

select * from member2;

commit --만약에 시스템 장애가 발생하면, commit이 된경우에는 복구가 가능합니다.
	--