package 상속;

public class 테스트 {
	public static void main(String[] args) {
		부모 부모님 = new 자식();
		부모님.키(); 
		
		자식 아들 = (자식)부모님;
		아들.키();
		아들.몸무게();
		
		
	}
}
