package 상속;

public class 부모 {
	void 키(){
		System.out.println("부모의 키는 170이다.");
	}
	
	
}
