package 상속;

public class 자식 extends 부모 {
	@Override
	void 키() {
		System.out.println("자식의 키는 180이다.");
	}
	void 몸무게(){
		System.out.println("자식의 몸무게는 70이다.");
	}
}
